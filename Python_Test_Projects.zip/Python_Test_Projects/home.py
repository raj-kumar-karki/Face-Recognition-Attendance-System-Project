# from tkinter import*
# from tkinter import ttk
# from train import Train
# from PIL import Image,ImageTk
# from student import Student
# from tkinter import messagebox
# from register import Register
# from train import Train
# from face_recognition import Face_Recognition
# from attendance import Attendance
# from developer import Developer
# import os
# from helpsupport import Helpsupport

# # =====================main program Face deteion system====================
                    
# class Face_Recognition_System:
#     def __init__(self,root):

#         self.root=root
#         self.root.geometry("1366x768+0+0")
#         self.root.title("Face_Recogonition_System")

#         # background image 
#         bg1=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\bgg.jpg")
#         bg1=bg1.resize((1366,768),Image.Resampling.LANCZOS)
#         self.photobg1=ImageTk.PhotoImage(bg1)

#         # set image as lable
#         bg_img = Label(self.root,image=self.photobg1)
#         bg_img.place(x=0,y=0,width=1366,height=768)


#         #title section
#         title_lb1 = Label(bg_img,text="Welcome To Admin Dashboard",font=("verdana",20,"bold"),bg="white",fg="navyblue")
#         title_lb1.place(x=0,y=0,width=1366,height=40)
        
#         #footer section
#         title_lb1 = Label(bg_img,text="Nirvana College ©2024",font=("verdana",20,"bold"),bg="white",fg="navyblue")
#         title_lb1.place(x=0,y=650,width=1366,height=40)

#         # Create buttons below the section 
#         # ------------------------------------------------------------------------------------------------------------------- 
#         # student button 1
#         std_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\std1.jpg")
#         std_img_btn=std_img_btn.resize((150,130),Image.Resampling.LANCZOS)
#         self.std_img1=ImageTk.PhotoImage(std_img_btn)

#         std_b1 = Button(bg_img,command=self.student_pannels,image=self.std_img1,cursor="hand2")
#         std_b1.place(x=250,y=110,width=150,height=130)

#         std_b1_1 = Button(bg_img,command=self.student_pannels,text="Student Panel",cursor="hand2",font=("tahoma",12,"bold"),bg="white",fg="navyblue")
#         std_b1_1.place(x=250,y=240,width=150,height=30)

#         # Detect Face  button 2
#         det_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\det1.jpg")
#         det_img_btn=det_img_btn.resize((150,130),Image.Resampling.LANCZOS)
#         self.det_img1=ImageTk.PhotoImage(det_img_btn)

#         det_b1 = Button(bg_img,command=self.face_rec,image=self.det_img1,cursor="hand2",)
#         det_b1.place(x=480,y=110,width=150,height=130)

#         det_b1_1 = Button(bg_img,command=self.face_rec,text="Face Detector",cursor="hand2",font=("tahoma",12,"bold"),bg="white",fg="navyblue")
#         det_b1_1.place(x=480,y=240,width=150,height=30)

#          # Attendance System  button 3
#         att_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\attendance.png")
#         att_img_btn=att_img_btn.resize((150,130),Image.Resampling.LANCZOS)
#         self.att_img1=ImageTk.PhotoImage(att_img_btn)

#         att_b1 = Button(bg_img,command=self.attendance_pannel,image=self.att_img1,cursor="hand2",)
#         att_b1.place(x=710,y=110,width=150,height=130)

#         att_b1_1 = Button(bg_img,command=self.attendance_pannel,text="Attendance",cursor="hand2",font=("tahoma",12,"bold"),bg="white",fg="navyblue")
#         att_b1_1.place(x=710,y=240,width=150,height=30)

#          # Help  Support  button 4
#         hlp_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\support.png")
#         hlp_img_btn=hlp_img_btn.resize((150,130),Image.Resampling.LANCZOS)
#         self.hlp_img1=ImageTk.PhotoImage(hlp_img_btn)

#         hlp_b1 = Button(bg_img,command=self.help,image=self.hlp_img1,cursor="hand2",)
#         hlp_b1.place(x=940,y=110,width=150,height=130)

#         hlp_b1_1 = Button(bg_img,command=self.help,text="Help Support",cursor="hand2",font=("tahoma",12,"bold"),bg="white",fg="navyblue")
#         hlp_b1_1.place(x=940,y=240,width=150,height=30)

#         # Top 4 buttons end.......
#         # ---------------------------------------------------------------------------------------------------------------------------
#         # Start below buttons.........
#          # Train   button 5
#         tra_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\tra1.jpg")
#         tra_img_btn=tra_img_btn.resize((150,130),Image.Resampling.LANCZOS)
#         self.tra_img1=ImageTk.PhotoImage(tra_img_btn)

#         tra_b1 = Button(bg_img,command=self.train_pannels,image=self.tra_img1,cursor="hand2",)
#         tra_b1.place(x=250,y=340,width=150,height=130)

#         tra_b1_1 = Button(bg_img,command=self.train_pannels,text="Data Train",cursor="hand2",font=("tahoma",12,"bold"),bg="white",fg="navyblue")
#         tra_b1_1.place(x=250,y=470,width=150,height=30)

#         # # Photo   button 6
#         # pho_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\qr1.jpg")
#         # pho_img_btn=pho_img_btn.resize((150,130),Image.Resampling.LANCZOS)
#         # self.pho_img1=ImageTk.PhotoImage(pho_img_btn)

#         # pho_b1 = Button(bg_img,command=self.open_img,image=self.pho_img1,cursor="hand2",)
#         # pho_b1.place(x=480,y=340,width=150,height=130)

#         # pho_b1_1 = Button(bg_img,command=self.open_img,text="Photos",cursor="hand2",font=("tahoma",12,"bold"),bg="white",fg="navyblue")
#         # pho_b1_1.place(x=480,y=470,width=150,height=40)

#           # Photo   button 6
#         pho_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\qr1.jpg")
#         pho_img_btn=pho_img_btn.resize((150,130),Image.Resampling.LANCZOS)
#         self.pho_img1=ImageTk.PhotoImage(pho_img_btn)

#         pho_b1 = Button(bg_img,command=self.register,image=self.pho_img1,cursor="hand2",)
#         pho_b1.place(x=480,y=340,width=150,height=130)

#         pho_b1_1 = Button(bg_img,command=self.register,text="Registration",cursor="hand2",font=("tahoma",12,"bold"),bg="white",fg="navyblue")
#         pho_b1_1.place(x=480,y=470,width=150,height=30)

#         # Developers   button 7
#         dev_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\dev.jpg")
#         dev_img_btn=dev_img_btn.resize((150,130),Image.Resampling.LANCZOS)
#         self.dev_img1=ImageTk.PhotoImage(dev_img_btn)

#         dev_b1 = Button(bg_img,command=self.developr,image=self.dev_img1,cursor="hand2",)
#         dev_b1.place(x=710,y=340,width=150,height=130)

#         dev_b1_1 = Button(bg_img,command=self.developr,text="Developers",cursor="hand2",font=("tahoma",12,"bold"),bg="white",fg="navyblue")
#         dev_b1_1.place(x=710,y=470,width=150,height=30)

#         # exit   button 8
#         exi_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\exi.jpg")
#         exi_img_btn=exi_img_btn.resize((150,130),Image.Resampling.LANCZOS)
#         self.exi_img1=ImageTk.PhotoImage(exi_img_btn)

#         exi_b1 = Button(bg_img,command=self.Close,image=self.exi_img1,cursor="hand2",)
#         exi_b1.place(x=940,y=340,width=150,height=130)

#         exi_b1_1 = Button(bg_img,command=self.Close,text="Exit",cursor="hand2",font=("tahoma",12,"bold"),bg="white",fg="navyblue")
#         exi_b1_1.place(x=940,y=470,width=150,height=30)

# # ==================Funtion for Open Images Folder==================
#     # def open_img(self):
#     #     os.startfile("data_img")
        
#     def register(self):
#         self.new_window=Toplevel(self.root)
#         self.app=Register(self.new_window)  
# # ==================Functions Buttons=====================
#     def student_pannels(self):
#         self.new_window=Toplevel(self.root)
#         self.app=Student(self.new_window)

#     def train_pannels(self):
#         self.new_window=Toplevel(self.root)
#         self.app=Train(self.new_window)
    
#     def face_rec(self):
#         self.new_window=Toplevel(self.root)
#         self.app=Face_Recognition(self.new_window)
    
#     def attendance_pannel(self):
#         self.new_window=Toplevel(self.root)
#         self.app=Attendance(self.new_window)
    
#     def developr(self):
#         self.new_window=Toplevel(self.root)
#         self.app=Developer(self.new_window)
    
#     # def open_img(self):
#     #     os.startfile("dataset")
        
#     def help(self):
#         self.new_window=Toplevel(self.root)
#         self.app=Helpsupport(self.new_window)
    
#     def Close(self):
#         root.destroy()


# if __name__ == "__main__":
#     root=Tk()
#     obj=Face_Recognition_System(root)
#     root.mainloop()
