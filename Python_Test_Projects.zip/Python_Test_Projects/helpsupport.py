from tkinter import*
from PIL import Image,ImageTk
from tkinter import messagebox
import tkinter as tk


class Helpsupport:
 def __init__(self,root):
        self.root=root
        self.root.geometry("1366x768+0+0")
        self.root.title("Help Support")

        # backgorund image 
        bg1=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\bg4.png")
        bg1=bg1.resize((1366,768),Image.Resampling.LANCZOS)
        self.photobg1=ImageTk.PhotoImage(bg1)

        # set image as lable
        bg_img = Label(self.root,image=self.photobg1)
        bg_img.place(x=0,y=0,width=1366,height=768)

 #frame design #4682b4
        frame1= Frame(self.root,bg="#4682b4")
        frame1.place(x=530,y=150,width=340,height=350)

        get_str = Label(frame1,text="!Click As you want to Know!",font=("times new roman",20,"bold"),fg="white",bg="#4682b4")
        get_str.place(x=-5,y=5)

        #title section
        title_lb1 = Label(bg_img,text="Welcome To Help & Support Panel",font=("verdana",20,"bold"),bg="white",fg="navyblue")
        title_lb1.place(x=0,y=0,width=1366,height=40)

# Creating Button 1
        loginbtn=Button(frame1,command=self.step,text="1. How to Run Program ?",cursor="hand2",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="white",bg="#4682b4",activeforeground="orange",activebackground="#4682b4")
        loginbtn.place(x=25,y=80,width=300,height=25)

# Creating Button 2
        loginbtn=Button(frame1,command=self.step1,text="2. Troubleshooting ?",cursor="hand2",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="white",bg="#4682b4",activeforeground="orange",activebackground="#4682b4")
        loginbtn.place(x=5,y=140,width=300,height=25)

# Creating Button 3
        loginbtn=Button(frame1,command=self.step2,text="3. Frequently Asked Questions ?",cursor="hand2",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="white",bg="#4682b4",activeforeground="orange",activebackground="#4682b4")
        loginbtn.place(x=55,y=200,width=300,height=25)

# Creating Button 4
        loginbtn=Button(frame1,command=self.step3,text="4. Conclusion:",cursor="hand2",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="white",bg="#4682b4",activeforeground="orange",activebackground="#4682b4")
        loginbtn.place(x=-25,y=260,width=300,height=25)

       
        #footer section
        title_lb2 = Label(bg_img,text="Nirvana College ©2024",font=("verdana",20,"bold"),bg="white",fg="navyblue")
        title_lb2.place(x=0,y=650,width=1366,height=40)


        # =====================message=========================================
 def step(self):
   messagebox.showinfo("About Project:","""
              1. Launching the System:
                 - Open the system interface (desktop application).
                 - Authenticate if necessary.

              2. Enrolling Students:
                 - Add student profiles to the system:
                 - Capture faces by a webcam & upload images.
                 - Assign unique IDs or names to each student.

              3. Taking Attendance:
                 - Access the attendance module.
                 - Start the webcam to detect faces in real-time.
                 - Recognize enrolled students & mark attendance.

              4. Viewing Attendance Records:
                 - Check daily/weekly/monthly attendance reports.
                 - Identify absentees and latecomers.""")
  
 def step1(self):
   messagebox.showinfo("Troubleshooting:","""
              1. Camera Issues:
                 - Ensure the webcam is functional.
                 - Check lighting conditions for accurate face 
                   detection.

              2. Recognition Accuracy:
                 - Train the system with diverse student images.
                 - Optimize face alignment and preprocessing 
                   techniques.

              3. False Positives/Negatives:
                 - Adjust recognition thresholds to minimize errors.
                 - Review unrecognized faces manually.""")
   
 def step2(self):
   messagebox.showinfo("Frequently Asked Questions (FAQs):","""
              1. How do I add new students?
                 - Navigate to the student management section 
                   &follow the enrollment process.

              2. Can I take attendance for multiple classes?
                 - Yes, create separate class profiles within the 
                   system.

              3. What if a student’s face is not recognized?
                 - Verify the student’s profile image quality.
                 - Retrain the system with additional images.""")
   
 def step3(self):
   messagebox.showinfo("Conclusion:","""
              The Face Recognition Attendance System simplifies 
              attendance tracking, reduces manual effort, and 
              enhances accuracy. Refer to this guide whenever 
              you need assistance or encounter issues.

              For detailed technical information, 
              refer to contact our support team.
                          
              contact: +977 9823267337   
              Email: jinraj917@gmail.com""")
       
if __name__ == "__main__":
    root=Tk()
    obj=Helpsupport(root)
    root.mainloop()
