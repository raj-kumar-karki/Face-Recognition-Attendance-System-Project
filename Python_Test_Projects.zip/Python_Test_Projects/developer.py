from tkinter import*
from tkinter import ttk
from train import Train
from PIL import Image,ImageTk
from student import Student
from train import Train
from face_recognition import Face_Recognition
from attendance import Attendance
import os

class Developer:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1366x768+0+0")
        self.root.title("Developer")

        # backgorund image 
        bg1=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\bg4.png")
        bg1=bg1.resize((1366,768),Image.Resampling.LANCZOS)
        self.photobg1=ImageTk.PhotoImage(bg1)

        # set image as lable
        bg_img = Label(self.root,image=self.photobg1)
        bg_img.place(x=0,y=0,width=1366,height=768)


        #title section
        title_lb1 = Label(bg_img,text="Developer",font=("verdana",20,"bold"),bg="white",fg="navyblue")
        title_lb1.place(x=0,y=0,width=1366,height=40)

        #detail section
        title_lb1 = Label(bg_img,text="My name is Raj Kumar Karki. I'm BCA Student.This system aims to build an effective class\n" 
                                      "attendance system using face recognition techniques. This system helps tp take to\n" 
                                      "mark the attendance via face Id. It will detect faces via webcam and then recognize the\n" 
                                      "faces. After recognition, it will mark the attendance of the recognized student and update\n"
                                      "the attendance record. I have developed a system that detects and recognizes students\n" 
                                      "faces and displays theirinformation and whether he was registered or not. This would be\n" 
                                      "possible by applying deep learningand image analysis algorithms to detect student faces.",font=("times new roman",15,"bold"),bg="#4682b4",fg="white",justify=LEFT)
        title_lb1.place(x=140,y=290,width=1100,height=250)

        #footer section
        title_lb1 = Label(bg_img,text="Nirvana College ©2024",font=("verdana",20,"bold"),bg="white",fg="navyblue")
        title_lb1.place(x=0,y=650,width=1366,height=40)

        # Create buttons below the section 
        # Attendance System  button 3
        att_img_btn=Image.open(r"C:\Users\pk450\Documents\Python_Test_Projects\Images_GUI\w.jpg")
        att_img_btn=att_img_btn.resize((200,200),Image.Resampling.LANCZOS)
        self.att_img1=ImageTk.PhotoImage(att_img_btn)

        att_b1 = Label(bg_img,image=self.att_img1)
        att_b1.place(x=570,y=90,width=200,height=200)

        # att_b1_1 = Button(bg_img,text="Raj Kumar Karki",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        # att_b1_1.place(x=570,y=290,width=200,height=45)

        # att_b1_1 = Button(bg_img,text="I'm BCA Student. This Project Based on Face Recognition with Attendance System.",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        # att_b1_1.place(x=215,y=335,width=900,height=70)


if __name__ == "__main__":
    root=Tk()
    obj=Developer(root)
    root.mainloop()